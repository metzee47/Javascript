import { renderOrderSummary } from "./checkout/order-summary.js";
import { updateOrderStatement } from "./checkout/payment-summary.js";
import '../backend/backend-practice.js'

updateOrderStatement()
renderOrderSummary()